package sfa.data.model

@Entity
@Table(name = "stock")
class Stock {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    var id: Int = _
    
    var symbol :String = _
    
    var index :Index = _
      
    var kurs :List[Kurs] 
	
	var stocktype :String = _
	
	
}



 