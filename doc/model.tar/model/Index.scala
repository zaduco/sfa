package sfa.data.model

@Entity
@Table(name = "index")
class Index {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    var id: Int = _
    
    var name :String = _
    
    var symbol :String = _
    
    var isin :String = _

    var kurs :List[Kurs]  
}



 