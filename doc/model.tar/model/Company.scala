package sfa.data.model

class Company {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    var id: Int = _
  
	var name:String = _
	
	var isin :String = _
	
	var stocks:List[Stock] 
	
	var fundamentaldata : List[FundamentalData]
	
	
}