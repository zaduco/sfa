package sfa.data.model

import java.util.Date

@Entity
@Table(name = "fundamentaldata")
class FundamentalData {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    var id: Int = _
  
	var key:String = _
	
	var value :String =_
	
	var date:List[Date] = _
	
	
	
	
}