package sfa.data.model

import java.util.Date

@Entity
@Table(name = "kurs")
class Kurs {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    var id: Int = _
    
    var date :Date = _
      
    var value:Double = _
    
}



 